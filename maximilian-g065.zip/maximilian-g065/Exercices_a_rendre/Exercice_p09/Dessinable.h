#ifndef PRJ_DESSINABLE_H
#define PRJ_DESSINABLE_H

class Dessinable
{
	public :
	virtual void dessine() const = 0;
};

#endif // PRJ_DESSINABLE_H
