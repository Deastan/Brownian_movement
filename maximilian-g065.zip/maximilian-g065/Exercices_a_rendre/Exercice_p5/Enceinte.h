class Enceinte
{
	private:
	double hauteur;
	double largeur;
	double profondeur;
	
	public:
/*================================================================================
 * Prototype du constructeur
 *================================================================================*/
	Enceinte();
	
};
