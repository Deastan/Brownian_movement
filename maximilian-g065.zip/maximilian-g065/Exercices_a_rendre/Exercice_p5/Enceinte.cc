#include <iostream>
#include "Enceinte.h"

using namespace std;

/*================================================================================
 * Definition du constructeur
 *================================================================================*/
	Enceinte()
	:hauteur(20), largeur(20), profondeur(20)
	{}
