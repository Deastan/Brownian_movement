#include "TXTArgon.h"

using namespace std;

int main() {
	
	TXTArgon argon(Vecteur(1, 1, 3.1), Vecteur(0, 0, -0.5));
	argon.dessine();
	
	return 0;
}
