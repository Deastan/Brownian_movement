#include "TXTNeon.h"

using namespace std;

int main() {
	
	TXTNeon neon(Vecteur(1, 18.5, 1), Vecteur(0, 0.2, 0));
	neon.dessine();
	
	return 0;
}
