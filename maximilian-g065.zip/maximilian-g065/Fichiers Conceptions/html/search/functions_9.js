var searchData=
[
  ['rotatephi',['RotatePhi',['../class_vue___open_g_l.html#a1da1dad7d2da5a1ef3f834cd4ac5a35e',1,'Vue_OpenGL']]],
  ['rotatetheta',['RotateTheta',['../class_vue___open_g_l.html#a088c8fb20c9ba9c25cd5aa5eaeac4e5c',1,'Vue_OpenGL']]]
];
