var searchData=
[
  ['fenetre',['Fenetre',['../class_fenetre.html#a3b78862724264ec79d0332f8f65632aa',1,'Fenetre::Fenetre(wxString const &amp;titre, wxSize const &amp;taille=wxDefaultSize, wxPoint const &amp;position=wxDefaultPosition, long style=wxDEFAULT_FRAME_STYLE)'],['../class_fenetre.html#a0c4225ac5a9b265b860a610204a37024',1,'Fenetre::Fenetre(wxString const &amp;titre, bool reglage, wxSize const &amp;taille=wxDefaultSize, wxPoint const &amp;position=wxDefaultPosition, long style=wxDEFAULT_FRAME_STYLE)']]]
];
